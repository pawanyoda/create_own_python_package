from setuptools import setup

setup(
    name='test_package_by_pawan',
    packages=['test'],
    description='test package',
    version='1.0.0',
    author='Pawan',
    author_email='pawan.yoda@gmail.com',
    keywords='test package'
)
